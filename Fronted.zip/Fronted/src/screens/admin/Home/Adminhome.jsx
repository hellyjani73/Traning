import './Adminhome.css'
import Adminsidebar from '../Components/AdminSidebar/Adminsidebar'

const Adminhome = () => {

  return (
    <>

    <Adminsidebar/>

    </>
    
  )
}

export default Adminhome