
# E-Commerce Web Application 🛒

An E commerce application built by using reactjs , nodejs , express js , mongo db with admin pannel!🔔


## Acknowledgements

The Main prupose of this e commerce of project is to learn about how the realtime crud opreation works with react, this project is not fully completed , that was not even moto to complete the main purpose was to just usderstand the concept and this project has well enough feature to understand how to integreate rest api with react  how to manage mutliple context api , how to sepreate buisness logic from ui and many more!


## Information ⚡

- user category based authentication
- Admin Section
- Admin can Upload Product
- Admin Can view Product
- User Can Access Products
- Complete Backend written using expressjs 
- data storage: MongoDB
- Used Multiple context api for integreation
- proper sepreation of buisness logic from ui logic




## 🚀 About Me
I'm a full stack developer currently pursuing B-tech CSE (2021)

i Code in Flutter Too


## Screenshots

Splash Screen
![App Screenshot](https://github.com/voiiddxx/bazaar/assets/95859137/6929b708-a0b2-477e-ac7f-f4d9b4ecd69d)
registration Screen
![App Screenshot](https://github.com/voiiddxx/bazaar/assets/95859137/7dc7b6c3-7b40-41af-84de-c642563a1e9c)
Login Screen
![App Screenshot](https://github.com/voiiddxx/bazaar/assets/95859137/a6832da6-23f8-4fbc-97fc-a5636c37d85a)
Admin pannel
![App Screenshot](https://github.com/voiiddxx/bazaar/assets/95859137/641d2304-0d1a-40d2-a75c-1f49eb5d651b)
Add product
![App Screenshot](https://github.com/voiiddxx/bazaar/assets/95859137/1383fcd6-a65f-47e6-a5d5-72dee3781ed8)
Admin Respective Product
![App Screenshot](https://github.com/voiiddxx/bazaar/assets/95859137/eb3594af-67d7-4c21-a586-66e858a6b72f)
Users Product 
![App Screenshot](https://github.com/voiiddxx/bazaar/assets/95859137/f6d20e47-4a1b-40b9-86ab-b89be029fccb)
![App Screenshot](https://github.com/voiiddxx/bazaar/assets/95859137/cfd40ebd-fa8a-43ae-9ff7-40f5f2d8af15)


## Tech Stack 💻

**Client:** React , CSS

**Server:** Node, Express

**Database:** MongoDB


## Demo

Insert gif or link to demo

    
## FAQ

#### Is it fully fledged e commerce?

No 

#### Is it enough to understand the react and node fundamentals

BIG YES


## Support

For support, email nikhildesign00@gmail.com

