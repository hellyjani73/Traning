const mongoose = require("mongoose");


const productSchema = mongoose.Schema({
    userId:{
        type:String,
        required: true,
    },
    name:{
        type:String,
        required: true,
    },
    detail:{
        type:String,
    },
    category:{
        type:String,
    },
    price:{
        type:String,
        required: true,
    },
    company:{
        type:String,
    },
    image:[
        {
            type:String
        }
    ]
});

const Product = mongoose.model("Product" , productSchema);

module.exports = Product;