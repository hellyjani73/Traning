const mongoose = require("mongoose");

const mongodbUrl =
  "mongodb+srv://jinaldevelopment:jinal@test.emq4k4a.mongodb.net/?retryWrites=true&w=majority&appName=Test";

const connectDb = async () => {
  try {
    await mongoose.connect(mongodbUrl, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("MongoDB connected");
  } catch (err) {
    console.error("MongoDB connection error:", err);
  }
};

module.exports = connectDb;
