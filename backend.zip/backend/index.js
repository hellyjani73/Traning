const express = require("express");
const connectDb = require("./config/db"); 
const authRouter = require("./routes/auth/auth");
const cors = require("cors");
const adminRouter = require("./routes/Admin/admin");
const PORT = 4000;

const app = express();

app.use(cors());
app.use(express.json());
app.use(authRouter);
app.use(adminRouter);

 


app.listen(PORT, async () => {
    await connectDb(console.log("mongo connected"));
    console.log(`Server running on port ${PORT}`);
  });
  